﻿
namespace TOPGames
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSair = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cadastroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usúarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.artigosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.locaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alugarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pbxCadProduto = new System.Windows.Forms.PictureBox();
            this.pbxAlugar = new System.Windows.Forms.PictureBox();
            this.pbxVenda = new System.Windows.Forms.PictureBox();
            this.pbxCadJogo = new System.Windows.Forms.PictureBox();
            this.PbxCadCliente = new System.Windows.Forms.PictureBox();
            this.pbxCadUser = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCadProduto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAlugar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVenda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCadJogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxCadCliente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCadUser)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.ForeColor = System.Drawing.Color.White;
            this.btnSair.Location = new System.Drawing.Point(632, 445);
            this.btnSair.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(147, 23);
            this.btnSair.TabIndex = 131;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroToolStripMenuItem,
            this.vendaToolStripMenuItem,
            this.alugarToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(793, 28);
            this.menuStrip1.TabIndex = 132;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cadastroToolStripMenuItem
            // 
            this.cadastroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usúarioToolStripMenuItem,
            this.clienteToolStripMenuItem,
            this.artigosToolStripMenuItem,
            this.locaçãoToolStripMenuItem});
            this.cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            this.cadastroToolStripMenuItem.Size = new System.Drawing.Size(82, 24);
            this.cadastroToolStripMenuItem.Text = "Cadastro";
            // 
            // usúarioToolStripMenuItem
            // 
            this.usúarioToolStripMenuItem.Name = "usúarioToolStripMenuItem";
            this.usúarioToolStripMenuItem.Size = new System.Drawing.Size(142, 26);
            this.usúarioToolStripMenuItem.Text = "Usuário";
            this.usúarioToolStripMenuItem.Click += new System.EventHandler(this.usúarioToolStripMenuItem_Click);
            // 
            // clienteToolStripMenuItem
            // 
            this.clienteToolStripMenuItem.Name = "clienteToolStripMenuItem";
            this.clienteToolStripMenuItem.Size = new System.Drawing.Size(142, 26);
            this.clienteToolStripMenuItem.Text = "Cliente";
            this.clienteToolStripMenuItem.Click += new System.EventHandler(this.clienteToolStripMenuItem_Click);
            // 
            // artigosToolStripMenuItem
            // 
            this.artigosToolStripMenuItem.Name = "artigosToolStripMenuItem";
            this.artigosToolStripMenuItem.Size = new System.Drawing.Size(142, 26);
            this.artigosToolStripMenuItem.Text = "Artigos";
            this.artigosToolStripMenuItem.Click += new System.EventHandler(this.artigosToolStripMenuItem_Click);
            // 
            // locaçãoToolStripMenuItem
            // 
            this.locaçãoToolStripMenuItem.Name = "locaçãoToolStripMenuItem";
            this.locaçãoToolStripMenuItem.Size = new System.Drawing.Size(142, 26);
            this.locaçãoToolStripMenuItem.Text = "Jogos";
            this.locaçãoToolStripMenuItem.Click += new System.EventHandler(this.locaçãoToolStripMenuItem_Click);
            // 
            // vendaToolStripMenuItem
            // 
            this.vendaToolStripMenuItem.Name = "vendaToolStripMenuItem";
            this.vendaToolStripMenuItem.Size = new System.Drawing.Size(64, 24);
            this.vendaToolStripMenuItem.Text = "Venda";
            this.vendaToolStripMenuItem.Click += new System.EventHandler(this.vendaToolStripMenuItem_Click);
            // 
            // alugarToolStripMenuItem
            // 
            this.alugarToolStripMenuItem.Name = "alugarToolStripMenuItem";
            this.alugarToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.alugarToolStripMenuItem.Text = "Alugar";
            this.alugarToolStripMenuItem.Click += new System.EventHandler(this.alugarToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(200, 221);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 25);
            this.label1.TabIndex = 138;
            this.label1.Text = "Cadastrar Cliente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 25);
            this.label2.TabIndex = 139;
            this.label2.Text = "Cadastrar Usuário";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(398, 221);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 25);
            this.label3.TabIndex = 140;
            this.label3.Text = "Cadastrar Jogo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(205, 439);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 25);
            this.label4.TabIndex = 141;
            this.label4.Text = "Alugar Jogo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 439);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 25);
            this.label5.TabIndex = 142;
            this.label5.Text = "Vender Artigo";
            // 
            // pbxCadProduto
            // 
            this.pbxCadProduto.Image = global::TOPGames.Properties.Resources.fly;
            this.pbxCadProduto.Location = new System.Drawing.Point(591, 31);
            this.pbxCadProduto.Name = "pbxCadProduto";
            this.pbxCadProduto.Size = new System.Drawing.Size(187, 187);
            this.pbxCadProduto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxCadProduto.TabIndex = 143;
            this.pbxCadProduto.TabStop = false;
            this.pbxCadProduto.Click += new System.EventHandler(this.pbxCadProduto_Click);
            // 
            // pbxAlugar
            // 
            this.pbxAlugar.Image = global::TOPGames.Properties.Resources.game_control;
            this.pbxAlugar.Location = new System.Drawing.Point(205, 249);
            this.pbxAlugar.Name = "pbxAlugar";
            this.pbxAlugar.Size = new System.Drawing.Size(187, 187);
            this.pbxAlugar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxAlugar.TabIndex = 137;
            this.pbxAlugar.TabStop = false;
            this.pbxAlugar.Click += new System.EventHandler(this.pbxAlugar_Click);
            // 
            // pbxVenda
            // 
            this.pbxVenda.Image = global::TOPGames.Properties.Resources.trade;
            this.pbxVenda.Location = new System.Drawing.Point(12, 249);
            this.pbxVenda.Name = "pbxVenda";
            this.pbxVenda.Size = new System.Drawing.Size(187, 187);
            this.pbxVenda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxVenda.TabIndex = 136;
            this.pbxVenda.TabStop = false;
            this.pbxVenda.Click += new System.EventHandler(this.pbxVenda_Click);
            // 
            // pbxCadJogo
            // 
            this.pbxCadJogo.Image = global::TOPGames.Properties.Resources.controle_de_video_game;
            this.pbxCadJogo.Location = new System.Drawing.Point(398, 31);
            this.pbxCadJogo.Name = "pbxCadJogo";
            this.pbxCadJogo.Size = new System.Drawing.Size(187, 187);
            this.pbxCadJogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxCadJogo.TabIndex = 135;
            this.pbxCadJogo.TabStop = false;
            this.pbxCadJogo.Click += new System.EventHandler(this.pbxCadJogo_Click);
            // 
            // PbxCadCliente
            // 
            this.PbxCadCliente.Image = global::TOPGames.Properties.Resources.man;
            this.PbxCadCliente.Location = new System.Drawing.Point(205, 31);
            this.PbxCadCliente.Name = "PbxCadCliente";
            this.PbxCadCliente.Size = new System.Drawing.Size(187, 187);
            this.PbxCadCliente.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbxCadCliente.TabIndex = 134;
            this.PbxCadCliente.TabStop = false;
            this.PbxCadCliente.Click += new System.EventHandler(this.PbxCadCliente_Click);
            // 
            // pbxCadUser
            // 
            this.pbxCadUser.Image = global::TOPGames.Properties.Resources.profile;
            this.pbxCadUser.Location = new System.Drawing.Point(12, 31);
            this.pbxCadUser.Name = "pbxCadUser";
            this.pbxCadUser.Size = new System.Drawing.Size(187, 187);
            this.pbxCadUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxCadUser.TabIndex = 133;
            this.pbxCadUser.TabStop = false;
            this.pbxCadUser.Click += new System.EventHandler(this.pbxCadUser_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(586, 220);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 25);
            this.label6.TabIndex = 144;
            this.label6.Text = "Cadastrar Artigo";
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(793, 480);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pbxCadProduto);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbxAlugar);
            this.Controls.Add(this.pbxVenda);
            this.Controls.Add(this.pbxCadJogo);
            this.Controls.Add(this.PbxCadCliente);
            this.Controls.Add(this.pbxCadUser);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TOP Games";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCadProduto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAlugar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVenda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCadJogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxCadCliente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCadUser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cadastroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usúarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem artigosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem locaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alugarToolStripMenuItem;
        private System.Windows.Forms.PictureBox pbxCadUser;
        private System.Windows.Forms.PictureBox PbxCadCliente;
        private System.Windows.Forms.PictureBox pbxCadJogo;
        private System.Windows.Forms.PictureBox pbxVenda;
        private System.Windows.Forms.PictureBox pbxAlugar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pbxCadProduto;
        private System.Windows.Forms.Label label6;
    }
}

